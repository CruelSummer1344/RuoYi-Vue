<template>
  <div class="booking">
    <h2>预约订购</h2>

    <!-- 项目筛选 -->
    <el-form inline class="search-form">
      <el-form-item label="搜索项目">
        <el-input v-model="searchQuery" placeholder="输入关键词搜索" clearable @input="filterProjects"></el-input>
      </el-form-item>
      <el-form-item label="日期">
        <el-date-picker v-model="selectedDate" type="date" placeholder="选择日期" @change="filterProjects"></el-date-picker>
      </el-form-item>
    </el-form>

    <!-- 项目列表 -->
    <el-row :gutter="20">
      <el-col :span="8" v-for="project in filteredProjects" :key="project.id">
        <el-card shadow="hover" class="project-card">
          <h3>{{ project.name }}</h3>
          <p>{{ project.description }}</p>
          <p><strong>价格：</strong>￥{{ project.price }}</p>
          <p><strong>可用日期：</strong>{{ project.availableDates.join(', ') }}</p>
          <p><strong>用户评价：</strong>{{ project.reviews.rating }} ({{ project.reviews.count }}条)</p>
          <p><strong>注意事项：</strong>{{ project.notes }}</p>
          <el-button type="primary" @click="selectProject(project)">立即预订</el-button>
        </el-card>
      </el-col>
    </el-row>

    <!-- 项目详情弹窗 -->
    <el-dialog title="预订详情" :visible.sync="dialogVisible" width="40%">
      <el-form :model="bookingForm" ref="bookingForm" :rules="rules" label-width="100px">
        <el-form-item label="项目名称" prop="projectName">
          <el-input v-model="bookingForm.projectName" disabled></el-input>
        </el-form-item>
        <el-form-item label="预订日期" prop="date">
          <el-date-picker v-model="bookingForm.date" type="date" placeholder="选择日期"></el-date-picker>
        </el-form-item>
        <el-form-item label="人数" prop="peopleCount">
          <el-input-number v-model="bookingForm.peopleCount" :min="1" :max="10"></el-input-number>
        </el-form-item>
        <el-form-item label="总价">
          <span>￥{{ totalPrice }}</span>
        </el-form-item>
        <el-form-item label="支付方式" prop="paymentMethod">
          <el-radio-group v-model="bookingForm.paymentMethod">
            <el-radio label="wechat">微信支付</el-radio>
            <el-radio label="alipay">支付宝</el-radio>
            <el-radio label="bank">银行卡</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="confirmBooking('bookingForm')">确认支付</el-button>
      </div>
    </el-dialog>

    <!-- 订单管理与查询 -->
    <div class="order-management">
      <h3>我的订单</h3>
      <!-- 订单查询 -->
      <el-form inline class="order-search-form">
        <el-form-item label="订单编号">
          <el-input v-model="orderQuery.orderId" placeholder="输入订单编号" clearable @input="filterOrders"></el-input>
        </el-form-item>
        <el-form-item label="项目名称">
          <el-input v-model="orderQuery.projectName" placeholder="输入项目名称" clearable @input="filterOrders"></el-input>
        </el-form-item>
        <el-form-item label="预订日期">
          <el-date-picker v-model="orderQuery.date" type="date" placeholder="选择日期" @change="filterOrders"></el-date-picker>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="filterOrders">查询</el-button>
          <el-button @click="resetOrderQuery">重置</el-button>
        </el-form-item>
      </el-form>

      <!-- 订单列表 -->
      <el-table :data="filteredOrders" stripe style="width: 100%" v-if="filteredOrders.length > 0">
        <el-table-column prop="orderId" label="订单编号" width="150"></el-table-column>
        <el-table-column prop="projectName" label="项目名称"></el-table-column>
        <el-table-column prop="date" label="预订日期" width="150"></el-table-column>
        <el-table-column prop="peopleCount" label="人数" width="100"></el-table-column>
        <el-table-column prop="totalPrice" label="总价" width="120"></el-table-column>
        <el-table-column prop="status" label="状态" width="100"></el-table-column>
        <el-table-column label="操作" width="250">
          <template slot-scope="scope">
            <el-button type="text" @click="editOrder(scope.row)" :disabled="scope.row.status !== '待支付'">修改</el-button>
            <el-button type="text" @click="cancelOrder(scope.row)" :disabled="scope.row.status !== '待支付'">取消</el-button>
            <el-button type="text" @click="goToReview(scope.row)" :disabled="scope.row.status !== '已支付'">去评价</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-else description="暂无订单"></el-empty>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Booking',
  data() {
    return {
      searchQuery: '',
      selectedDate: '',
      projects: [
        {
          id: 1,
          name: '生态观鸟之旅',
          description: '探索黄河三角洲湿地，观赏珍稀鸟类。',
          price: 200,
          availableDates: ['2025-03-08', '2025-03-15', '2025-03-22'],
          reviews: { rating: '4.8', count: 120 },
          notes: '请携带望远镜，穿着舒适鞋子。'
        },
        {
          id: 2,
          name: '黄河文化深度游',
          description: '探访孙子故里，体验渔家生活。',
          price: 300,
          availableDates: ['2025-03-09', '2025-03-16', '2025-03-23'],
          reviews: { rating: '4.5', count: 85 },
          notes: '建议提前预订渔家民宿。'
        }
      ],
      filteredProjects: [],
      dialogVisible: false,
      bookingForm: {
        projectId: '',
        projectName: '',
        date: '',
        peopleCount: 1,
        paymentMethod: 'wechat'
      },
      rules: {
        date: [{ required: true, message: '请选择日期', trigger: 'change' }],
        peopleCount: [{ required: true, message: '请选择人数', trigger: 'change' }],
        paymentMethod: [{ required: true, message: '请选择支付方式', trigger: 'change' }]
      },
      orders: [], // 所有订单
      filteredOrders: [], // 筛选后的订单
      orderQuery: {
        orderId: '',
        projectName: '',
        date: ''
      }
    };
  },
  computed: {
    totalPrice() {
      const project = this.projects.find(p => p.id === this.bookingForm.projectId);
      return project ? (project.price * this.bookingForm.peopleCount).toFixed(2) : 0;
    }
  },
  created() {
    this.filteredProjects = [...this.projects];
    this.loadOrders(); // 初始化加载订单
  },
  methods: {
    goToReview(row) {
      this.$router.push({ path: '/reviews', query: { projectId: row.projectId } });
    },
    // 筛选项目
    filterProjects() {
      this.filteredProjects = this.projects.filter(project => {
        const matchesQuery = this.searchQuery ? project.name.includes(this.searchQuery) : true;
        const matchesDate = this.selectedDate
            ? project.availableDates.includes(this.selectedDate.toISOString().split('T')[0])
            : true;
        return matchesQuery && matchesDate;
      });
    },
    // 选择项目
    selectProject(project) {
      this.bookingForm.projectId = project.id;
      this.bookingForm.projectName = project.name;
      this.dialogVisible = true;
    },
    // 确认支付
    confirmBooking(formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          this.$axios.post('/api/orders/create', {
            projectId: this.bookingForm.projectId,
            date: this.bookingForm.date,
            peopleCount: this.bookingForm.peopleCount,
            totalPrice: this.totalPrice,
            paymentMethod: this.bookingForm.paymentMethod
          }).then(response => {
            if (response.data.code === 200) {
              this.$message.success('订单创建成功，请完成支付');
              this.payOrder(response.data.orderId);
            } else {
              this.$message.error('订单创建失败：' + response.data.msg);
            }
          }).catch(() => {
            this.$message.error('订单提交失败');
          });
        }
      });
    },
    // 模拟支付
    payOrder(orderId) {
      this.$axios.post('/api/pay', {
        orderId,
        amount: this.totalPrice,
        method: this.bookingForm.paymentMethod
      }).then(response => {
        if (response.data.code === 200) {
          this.$message.success('支付成功！订单已确认');
          this.orders.push({
            orderId,
            projectName: this.bookingForm.projectName,
            date: this.bookingForm.date.toISOString().split('T')[0],
            peopleCount: this.bookingForm.peopleCount,
            totalPrice: this.totalPrice,
            status: '已支付'
          });
          this.filteredOrders = [...this.orders];
          this.dialogVisible = false;
          this.$refs['bookingForm'].resetFields();
          this.$confirm('支付成功！是否现在评价？', '提示', {
            confirmButtonText: '去评价',
            cancelButtonText: '稍后',
            type: 'success'
          }).then(() => {
            this.$router.push({ path: '/reviews', query: { projectId: this.bookingForm.projectId } });
          });
        }
      }).catch(() => {
        this.$message.error('支付请求失败');
      });
    },
    // 加载订单
    loadOrders() {
      this.orders = [
        {
          orderId: 'ORD202503070001',
          projectId: 1,
          projectName: '生态观鸟之旅',
          date: '2025-03-08',
          peopleCount: 2,
          totalPrice: '400.00',
          status: '已支付'
        },
        {
          orderId: 'ORD202503070002',
          projectId: 2,
          projectName: '黄河文化深度游',
          date: '2025-03-09',
          peopleCount: 1,
          totalPrice: '300.00',
          status: '待支付'
        },
        {
          orderId: 'ORD202503070003',
          projectId: 1,
          projectName: '生态观鸟之旅',
          date: '2025-03-15',
          peopleCount: 3,
          totalPrice: '600.00',
          status: '已支付'
        }
      ];
      this.filteredOrders = [...this.orders];
      // this.$axios.get('/api/orders/my').then(response => {
      //   if (response.data.code === 200) {
      //     this.orders = response.data.data;
      //     this.filteredOrders = [...this.orders]; // 初始化筛选结果
      //   }
      // }).catch(() => {
      //   this.$message.error('加载订单失败');
      // });
    },
    // 筛选订单
    filterOrders() {
      this.filteredOrders = this.orders.filter(order => {
        const matchesOrderId = this.orderQuery.orderId ? order.orderId.includes(this.orderQuery.orderId) : true;
        const matchesProjectName = this.orderQuery.projectName ? order.projectName.includes(this.orderQuery.projectName) : true;
        const matchesDate = this.orderQuery.date
            ? order.date === this.orderQuery.date.toISOString().split('T')[0]
            : true;
        return matchesOrderId && matchesProjectName && matchesDate;
      });
    },
    // 重置查询条件
    resetOrderQuery() {
      this.orderQuery.orderId = '';
      this.orderQuery.projectName = '';
      this.orderQuery.date = '';
      this.filteredOrders = [...this.orders];
    },
    // 修改订单
    editOrder(row) {
      this.$prompt('请输入新的预订人数', '修改订单', {
        inputValue: row.peopleCount,
        inputType: 'number',
        confirmButtonText: '确定',
        cancelButtonText: '取消'
      }).then(({ value }) => {
        this.$axios.put('/api/orders/update', {
          orderId: row.orderId,
          peopleCount: parseInt(value)
        }).then(response => {
          if (response.data.code === 200) {
            row.peopleCount = parseInt(value);
            row.totalPrice = (this.projects.find(p => p.name === row.projectName).price * value).toFixed(2);
            this.$message.success('订单修改成功');
            this.filterOrders(); // 更新筛选结果
          } else {
            this.$message.error('修改失败：' + response.data.msg);
          }
        });
      });
    },
    // 取消订单
    cancelOrder(row) {
      this.$confirm('确定取消此订单吗？', '提示', {
        type: 'warning'
      }).then(() => {
        this.$axios.delete(`/api/orders/cancel/${row.orderId}`).then(response => {
          if (response.data.code === 200) {
            this.orders = this.orders.filter(o => o.orderId !== row.orderId);
            this.filterOrders(); // 更新筛选结果
            this.$message.success('订单已取消');
          } else {
            this.$message.error('取消失败：' + response.data.msg);
          }
        });
      });
    }
  }
};
</script>

<style scoped>
.booking {
  padding: 20px;
  max-width: 1200px;
  margin: 0 auto;
}

h2, h3 {
  text-align: center;
  color: #303133;
  margin-bottom: 20px;
}

.search-form, .order-search-form {
  margin-bottom: 20px;
}

.project-card {
  margin-bottom: 20px;
}

.project-card h3 {
  color: #409eff;
  margin: 0 0 10px 0;
}

.project-card p {
  color: #606266;
  margin: 5px 0;
}

.order-management {
  margin-top: 40px;
}

.order-search-form {
  background: #f5f7fa;
  padding: 10px;
  border-radius: 8px;
}
</style>